<!DOCTYPE html>
<html lang="ko">
  <head?>
    <meta charset="utf-8">
    <title>무작위 숫자 생성</title>
  </head>
  <body>
    <p>1에서 100까지 무작위 숫자 생성하기:
      <?php

      echo rand(1,100);

      ?>
  </body>
</html>