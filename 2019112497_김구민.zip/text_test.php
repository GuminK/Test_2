<!DOCTYPE html>
<html lang="ko">
  <head?>
    <meta charset="utf-8">
    <title>문자열 테스트</title>
  </head>
  <body>
    <p>이것은 <strong>텍스트 테스트</strong>
      <?php

      echo '이것은 <strong> 텍스트 테스트 입니다.</strong>';

      ?>
  </body>
</html>