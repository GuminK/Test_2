<?php
//diceroll.php
//주사위 던져서 6이 나오면 이기는 게임 코드
echo '<h1>주사위 게임</h1>';
echo '<h2>나와야 할 숫자 : 6</h2>';
// 주사위 던지기 10번 반복
for($count = 1; $count<=10;$count++){
	$roll = rand(1,6);
	echo $count.' 회 째 입니다';
	echo '<font color = "red">주사위를 굴려서 나온 숫자: </font>'.$roll;
	echo '<br><br>';

	if ($roll ==6){
		echo 'Win!';
		
	}
	else{
		echo '꽝!';
		echo '<br><br>';
		echo '[계속 진행하세요!]';
	}
	echo '<br><br>';
}
echo '게임 종료';
?>